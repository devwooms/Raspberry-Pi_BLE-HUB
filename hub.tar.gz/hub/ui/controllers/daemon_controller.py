#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
데몬 관리 컨트롤러
"""

class DaemonManagerController:
    """데몬 매니저 UI 컨트롤러 클래스"""
    
    def __init__(self, daemon_controller, menu_view):
        """초기화
        
        Args:
            daemon_controller: 데몬 컨트롤러 인스턴스
            menu_view: 메뉴 뷰 인스턴스
        """
        self.daemon_controller = daemon_controller
        self.menu_view = menu_view
    
    def daemon_menu(self):
        """데몬 관리 메뉴"""
        while True:
            self.menu_view.clear_screen()
            self.menu_view.show_header("데몬 관리")
            
            # 현재 데몬 상태 표시
            daemon_status = self.daemon_controller.get_status()
            self.menu_view.show_message(f"\n데몬 상태: {daemon_status}")
            
            # 메뉴 옵션
            if "실행 중" in daemon_status:
                options = {
                    "1": "데몬 중지",
                    "2": "데몬 재시작",
                    "3": "로그 확인",
                    "0": "이전 메뉴로 돌아가기"
                }
            else:
                options = {
                    "1": "데몬 시작",
                    "3": "로그 확인",
                    "0": "이전 메뉴로 돌아가기"
                }
            
            self.menu_view.show_menu_options(options)
            choice = input("\n선택: ")
            
            if choice == "1":
                if "실행 중" in daemon_status:
                    self._stop_daemon()
                else:
                    self._start_daemon()
            elif choice == "2" and "실행 중" in daemon_status:
                self._restart_daemon()
            elif choice == "3":
                self._view_logs()
            elif choice == "0":
                break
            else:
                self.menu_view.show_error("잘못된 선택입니다. 다시 시도해주세요.")
                self.menu_view.wait_for_input()
    
    def _start_daemon(self):
        """데몬 시작"""
        self.menu_view.clear_screen()
        self.menu_view.show_header("데몬 시작")
        
        self.menu_view.show_message("데몬을 시작합니다...")
        if self.daemon_controller.start():
            self.menu_view.show_message("데몬이 시작되었습니다.")
        else:
            self.menu_view.show_error("데몬 시작에 실패했습니다.")
        
        self.menu_view.wait_for_input()
    
    def _stop_daemon(self):
        """데몬 중지"""
        self.menu_view.clear_screen()
        self.menu_view.show_header("데몬 중지")
        
        self.menu_view.show_message("데몬을 중지합니다...")
        if self.daemon_controller.stop():
            self.menu_view.show_message("데몬이 중지되었습니다.")
        else:
            self.menu_view.show_error("데몬 중지에 실패했습니다.")
        
        self.menu_view.wait_for_input()
    
    def _restart_daemon(self):
        """데몬 재시작"""
        self.menu_view.clear_screen()
        self.menu_view.show_header("데몬 재시작")
        
        self.menu_view.show_message("데몬을 재시작합니다...")
        if self.daemon_controller.restart():
            self.menu_view.show_message("데몬이 재시작되었습니다.")
        else:
            self.menu_view.show_error("데몬 재시작에 실패했습니다.")
        
        self.menu_view.wait_for_input()
    
    def _view_logs(self):
        """데몬 로그 확인"""
        self.menu_view.clear_screen()
        self.menu_view.show_header("데몬 로그")
        
        # 라인 수 입력 받기
        try:
            lines = int(input("확인할 로그 라인 수 (기본: 20): ") or "20")
            if lines < 1:
                lines = 20
        except ValueError:
            lines = 20
        
        log_content = self.daemon_controller.get_log(lines)
        
        self.menu_view.show_message("\n=== 로그 내용 ===\n")
        self.menu_view.show_message(log_content if log_content else "로그가 없습니다.")
        
        self.menu_view.wait_for_input() 