#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
디바이스 관리 컨트롤러
"""

import time
from hub.core.bluetooth.device_manager import BluetoothDeviceManager
from hub.core.model.device_model import DeviceModel

class DeviceController:
    """디바이스 관리 컨트롤러 클래스"""
    
    def __init__(self, device_model, menu_view):
        """컨트롤러 초기화
        
        Args:
            device_model (DeviceModel): 디바이스 모델
            menu_view (MenuView): 메뉴 뷰
        """
        self.device_model = device_model
        self.menu_view = menu_view
        self.device_manager = BluetoothDeviceManager()
    
    def device_menu(self):
        """디바이스 관리 메뉴"""
        while True:
            self.menu_view.clear_screen()
            self.menu_view.show_header("블루투스 디바이스 관리")
            
            # 현재 상태 표시
            self.menu_view.show_status_info(
                "정보 없음",  # 데몬 상태는 이 메뉴에서 관리하지 않음
                self.device_model.get_source_module(),
                self.device_model.get_target_module(),
                self.device_model.get_receiving_devices(),
                self.device_model.get_transmitting_device()
            )
            
            options = {
                "1": "수신 블루투스 모듈 설정",
                "2": "송신 블루투스 모듈 설정",
                "3": "수신 디바이스 추가",
                "4": "수신 디바이스 삭제",
                "5": "송신 디바이스 선택",
                "6": "송신 디바이스 삭제",
                "0": "이전 메뉴로 돌아가기"
            }
            
            self.menu_view.show_menu_options(options)
            choice = input("\n선택: ")
            
            if choice == "1":
                self._set_source_module()
            elif choice == "2":
                self._set_target_module()
            elif choice == "3":
                self._add_receiving_device()
            elif choice == "4":
                self._delete_receiving_device()
            elif choice == "5":
                self._select_transmitting_device()
            elif choice == "6":
                self._delete_transmitting_device()
            elif choice == "0":
                break
            else:
                self.menu_view.show_error("잘못된 선택입니다. 다시 시도해주세요.")
                self.menu_view.wait_for_input()
    
    def _set_source_module(self):
        """수신 블루투스 모듈 설정"""
        self.menu_view.clear_screen()
        self.menu_view.show_header("수신 블루투스 모듈 설정")
        
        interfaces = self.device_manager.get_bluetooth_interfaces()
        if not interfaces:
            self.menu_view.show_error("블루투스 인터페이스를 찾을 수 없습니다.")
            self.menu_view.wait_for_input()
            return
        
        print("사용 가능한 블루투스 인터페이스:")
        for i, interface in enumerate(interfaces, 1):
            print(f"{i}. {interface}")
        
        try:
            choice = int(input("\n인터페이스 선택 (숫자): "))
            if 1 <= choice <= len(interfaces):
                self.device_model.set_source_module(interfaces[choice-1])
                self.menu_view.show_message(f"소스 모듈이 {interfaces[choice-1]}로 설정되었습니다.")
            else:
                self.menu_view.show_error("잘못된 선택입니다.")
        except ValueError:
            self.menu_view.show_error("숫자를 입력해주세요.")
        
        self.menu_view.wait_for_input()
    
    def _set_target_module(self):
        """송신 블루투스 모듈 설정"""
        self.menu_view.clear_screen()
        self.menu_view.show_header("송신 블루투스 모듈 설정")
        
        interfaces = self.device_manager.get_bluetooth_interfaces()
        if not interfaces:
            self.menu_view.show_error("블루투스 인터페이스를 찾을 수 없습니다.")
            self.menu_view.wait_for_input()
            return
        
        print("사용 가능한 블루투스 인터페이스:")
        for i, interface in enumerate(interfaces, 1):
            print(f"{i}. {interface}")
        
        try:
            choice = int(input("\n인터페이스 선택 (숫자): "))
            if 1 <= choice <= len(interfaces):
                self.device_model.set_target_module(interfaces[choice-1])
                self.menu_view.show_message(f"타겟 모듈이 {interfaces[choice-1]}로 설정되었습니다.")
            else:
                self.menu_view.show_error("잘못된 선택입니다.")
        except ValueError:
            self.menu_view.show_error("숫자를 입력해주세요.")
        
        self.menu_view.wait_for_input()
    
    def _get_scan_timeout(self):
        """스캔 타임아웃 입력 받기
        
        Returns:
            int: 스캔 타임아웃 (초)
        """
        while True:
            try:
                timeout = int(input("스캔 시간 (5-120초): "))
                if 5 <= timeout <= 120:
                    return timeout
                self.menu_view.show_error("스캔 시간은 5초에서 120초 사이로 입력해주세요.")
            except ValueError:
                self.menu_view.show_error("숫자를 입력해주세요.")
    
    def _add_receiving_device(self):
        """수신 디바이스 추가"""
        self.menu_view.clear_screen()
        self.menu_view.show_header("수신 디바이스 추가")
        
        source_module = self.device_model.get_source_module()
        if not source_module:
            self.menu_view.show_error("수신 블루투스 모듈이 설정되지 않았습니다. 먼저 모듈을 설정해주세요.")
            self.menu_view.wait_for_input()
            return
        
        scan_timeout = self._get_scan_timeout()
        self.menu_view.show_message(f"\n{source_module} 인터페이스로 {scan_timeout}초간 블루투스 디바이스 스캔 중...")
        
        # 스캔 진행률 표시하며 디바이스 스캔
        devices = self.device_manager.scan_with_progress(source_module, scan_timeout)
        
        if not devices:
            self.menu_view.show_error("\n발견된 디바이스가 없습니다.")
            self.menu_view.wait_for_input()
            return
        
        print("\n발견된 디바이스:")
        for i, device in enumerate(devices, 1):
            print(f"{i}. {device['name']} ({device['mac']}) - RSSI: {device.get('rssi', 'N/A')}")
        
        try:
            choice = int(input("\n추가할 디바이스 선택 (숫자): "))
            if 1 <= choice <= len(devices):
                selected_device = devices[choice-1]
                
                # 중복 체크
                existing_devices = self.device_model.get_receiving_devices()
                for device in existing_devices:
                    if device['mac'] == selected_device['mac']:
                        self.menu_view.show_error("이미 추가된 디바이스입니다.")
                        self.menu_view.wait_for_input()
                        return
                
                self.device_model.add_receiving_device(selected_device)
                self.menu_view.show_message(f"{selected_device['name']} 디바이스가 추가되었습니다.")
            else:
                self.menu_view.show_error("잘못된 선택입니다.")
        except ValueError:
            self.menu_view.show_error("숫자를 입력해주세요.")
        
        self.menu_view.wait_for_input()
    
    def _delete_receiving_device(self):
        """수신 디바이스 삭제"""
        self.menu_view.clear_screen()
        self.menu_view.show_header("수신 디바이스 삭제")
        
        devices = self.device_model.get_receiving_devices()
        if not devices:
            self.menu_view.show_error("등록된 수신 디바이스가 없습니다.")
            self.menu_view.wait_for_input()
            return
        
        print("등록된 수신 디바이스:")
        for i, device in enumerate(devices, 1):
            print(f"{i}. {device['name']} ({device['mac']})")
        
        try:
            choice = int(input("\n삭제할 디바이스 선택 (숫자): "))
            if 1 <= choice <= len(devices):
                device = devices[choice-1]
                self.device_model.remove_receiving_device(device)
                self.menu_view.show_message(f"{device['name']} 디바이스가 삭제되었습니다.")
            else:
                self.menu_view.show_error("잘못된 선택입니다.")
        except ValueError:
            self.menu_view.show_error("숫자를 입력해주세요.")
        
        self.menu_view.wait_for_input()
    
    def _select_transmitting_device(self):
        """송신 디바이스 선택"""
        self.menu_view.clear_screen()
        self.menu_view.show_header("송신 디바이스 선택")
        
        target_module = self.device_model.get_target_module()
        if not target_module:
            self.menu_view.show_error("송신 블루투스 모듈이 설정되지 않았습니다. 먼저 모듈을 설정해주세요.")
            self.menu_view.wait_for_input()
            return
        
        scan_timeout = self._get_scan_timeout()
        self.menu_view.show_message(f"\n{target_module} 인터페이스로 {scan_timeout}초간 블루투스 디바이스 스캔 중...")
        
        # 스캔 진행률 표시하며 디바이스 스캔
        devices = self.device_manager.scan_with_progress(target_module, scan_timeout)
        
        if not devices:
            self.menu_view.show_error("\n발견된 디바이스가 없습니다.")
            self.menu_view.wait_for_input()
            return
        
        print("\n발견된 디바이스:")
        for i, device in enumerate(devices, 1):
            print(f"{i}. {device['name']} ({device['mac']}) - RSSI: {device.get('rssi', 'N/A')}")
        
        try:
            choice = int(input("\n선택할 디바이스 번호: "))
            if 1 <= choice <= len(devices):
                selected_device = devices[choice-1]
                self.device_model.set_transmitting_device(selected_device)
                self.menu_view.show_message(f"{selected_device['name']} 디바이스가 송신 디바이스로 설정되었습니다.")
            else:
                self.menu_view.show_error("잘못된 선택입니다.")
        except ValueError:
            self.menu_view.show_error("숫자를 입력해주세요.")
        
        self.menu_view.wait_for_input()
    
    def _delete_transmitting_device(self):
        """송신 디바이스 삭제"""
        self.menu_view.clear_screen()
        self.menu_view.show_header("송신 디바이스 삭제")
        
        transmitting_device = self.device_model.get_transmitting_device()
        if not transmitting_device:
            self.menu_view.show_error("설정된 송신 디바이스가 없습니다.")
            self.menu_view.wait_for_input()
            return
        
        confirm = input(f"{transmitting_device['name']} 디바이스를 삭제하시겠습니까? (y/n): ")
        if confirm.lower() == 'y':
            self.device_model.clear_transmitting_device()
            self.menu_view.show_message("송신 디바이스가 삭제되었습니다.")
        
        self.menu_view.wait_for_input() 