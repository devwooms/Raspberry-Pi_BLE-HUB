#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
블루투스 릴레이 컨트롤러
"""

class RelayController:
    """블루투스 릴레이 UI 컨트롤러 클래스"""
    
    def __init__(self, relay_service, device_model, menu_view):
        """초기화
        
        Args:
            relay_service: 릴레이 서비스 인스턴스
            device_model: 디바이스 모델 인스턴스
            menu_view: 메뉴 뷰 인스턴스
        """
        self.relay_service = relay_service
        self.device_model = device_model
        self.menu_view = menu_view
    
    def relay_menu(self):
        """릴레이 관리 메뉴"""
        while True:
            self.menu_view.clear_screen()
            self.menu_view.show_header("블루투스 릴레이 관리")
            
            # 현재 상태 조회
            relay_status = "실행 중" if self.relay_service.is_running() else "중지됨"
            
            # 상태 정보 표시
            self.menu_view.show_status_info(
                relay_status,
                self.device_model.get_source_module(),
                self.device_model.get_target_module(),
                self.device_model.get_receiving_devices(),
                self.device_model.get_transmitting_device()
            )
            
            # 릴레이 준비 상태에 따른 메뉴 옵션 구성
            options = {}
            if self.relay_service.is_running():
                options["1"] = "릴레이 중지"
            else:
                options["1"] = "릴레이 시작"
            
            options["2"] = "릴레이 상태 확인"
            options["0"] = "이전 메뉴로 돌아가기"
            
            self.menu_view.show_menu_options(options)
            choice = input("\n선택: ")
            
            if choice == "1":
                if self.relay_service.is_running():
                    self._stop_relay()
                else:
                    self._start_relay()
            elif choice == "2":
                self._check_status()
            elif choice == "0":
                break
            else:
                self.menu_view.show_error("잘못된 선택입니다. 다시 시도해주세요.")
                self.menu_view.wait_for_input()
    
    def _start_relay(self):
        """릴레이 시작"""
        self.menu_view.clear_screen()
        self.menu_view.show_header("릴레이 시작")
        
        # 릴레이 시작 전 필요한 조건 확인
        if not self.device_model.is_ready_for_relay():
            self.menu_view.show_error("릴레이 시작을 위한 필수 설정이 부족합니다.")
            
            # 부족한 설정 표시
            if not self.device_model.get_source_module():
                self.menu_view.show_error("- 수신용 블루투스 모듈이 설정되지 않았습니다.")
            
            if not self.device_model.get_target_module():
                self.menu_view.show_error("- 송신용 블루투스 모듈이 설정되지 않았습니다.")
            
            if not self.device_model.get_receiving_devices():
                self.menu_view.show_error("- 등록된 수신 디바이스가 없습니다.")
            
            if not self.device_model.get_transmitting_device():
                self.menu_view.show_error("- 송신 디바이스가 설정되지 않았습니다.")
            
            self.menu_view.wait_for_input()
            return
        
        # 릴레이 시작
        self.menu_view.show_message("릴레이 서비스를 시작합니다...")
        
        if self.relay_service.start_relay():
            self.menu_view.show_message("릴레이 서비스가 시작되었습니다.")
        else:
            self.menu_view.show_error("릴레이 서비스 시작 중 오류가 발생했습니다.")
        
        self.menu_view.wait_for_input()
    
    def _stop_relay(self):
        """릴레이 중지"""
        self.menu_view.clear_screen()
        self.menu_view.show_header("릴레이 중지")
        
        # 릴레이 중지
        self.menu_view.show_message("릴레이 서비스를 중지합니다...")
        
        if self.relay_service.stop_relay():
            self.menu_view.show_message("릴레이 서비스가 중지되었습니다.")
        else:
            self.menu_view.show_error("릴레이 서비스 중지 중 오류가 발생했습니다.")
        
        self.menu_view.wait_for_input()
    
    def _check_status(self):
        """릴레이 상태 확인"""
        self.menu_view.clear_screen()
        self.menu_view.show_header("릴레이 상태 확인")
        
        status = "실행 중" if self.relay_service.is_running() else "중지됨"
        self.menu_view.show_message(f"현재 릴레이 상태: {status}")
        
        if self.relay_service.is_running():
            self.menu_view.show_message("\n* 릴레이 작동 중 *")
            self.menu_view.show_message("수신 디바이스에서 전송되는 데이터를 수집하여")
            self.menu_view.show_message("송신 디바이스로 전달하는 중입니다.")
            
            # 연결된 디바이스 정보 표시
            receiving_devices = self.device_model.get_receiving_devices()
            transmitting_device = self.device_model.get_transmitting_device()
            
            self.menu_view.show_message("\n연결된 수신 디바이스:")
            for device in receiving_devices:
                self.menu_view.show_message(f"- {device['name']} ({device['mac']})")
            
            self.menu_view.show_message("\n연결된 송신 디바이스:")
            self.menu_view.show_message(f"- {transmitting_device['name']} ({transmitting_device['mac']})")
        else:
            self.menu_view.show_message("\n릴레이가 중지된 상태입니다.")
            self.menu_view.show_message("릴레이를 시작하려면 메뉴에서 '릴레이 시작'을 선택하세요.")
        
        self.menu_view.wait_for_input() 