#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
메뉴 화면 표시 관련 클래스
"""

import os
import platform

class MenuView:
    """메뉴 화면 표시 클래스"""
    
    def __init__(self):
        """메뉴 뷰 초기화"""
        # 터미널 크기
        self.width = 60
    
    def clear_screen(self):
        """화면 지우기"""
        os_name = platform.system()
        if os_name == "Windows":
            os.system("cls")
        else:
            os.system("clear")
    
    def show_header(self, title):
        """헤더 표시
        
        Args:
            title (str): 표시할 제목
        """
        print("\n" + "=" * self.width)
        print(f"{title:^{self.width}}")
        print("=" * self.width)
    
    def show_status_info(self, daemon_status, source_module, target_module, 
                         receiving_devices, transmitting_device):
        """상태 정보 표시
        
        Args:
            daemon_status (str): 데몬 상태
            source_module (str): 수신용 블루투스 모듈 정보
            target_module (str): 송신용 블루투스 모듈 정보
            receiving_devices (list): 수신 디바이스 목록
            transmitting_device (dict): 송신 디바이스 정보
        """
        print(f"\n데몬 상태 : {daemon_status}")
        print(f"수신용 블루투스 모듈 : {source_module if source_module else '없음'}")
        print(f"송신용 블루투스 모듈 : {target_module if target_module else '없음'}")
        
        print("\n수신 블루투스 디바이스 :")
        if receiving_devices:
            for device in receiving_devices:
                print(f"{device['name']} ({device['mac']})")
        else:
            print("등록된 디바이스 없음")
        
        print("\n송신 블루투스 디바이스 :")
        if transmitting_device:
            print(f"{transmitting_device['name']} ({transmitting_device['mac']})")
        else:
            print("설정된 디바이스 없음")
    
    def show_menu_options(self, options):
        """메뉴 옵션 표시
        
        Args:
            options (dict): 메뉴 옵션 (키: 선택번호, 값: 옵션 설명)
        """
        print("\n메뉴:")
        for key, value in options.items():
            print(f"{key}. {value}")
    
    def show_message(self, message):
        """메시지 표시
        
        Args:
            message (str): 표시할 메시지
        """
        print(message)
    
    def show_error(self, error_message):
        """오류 메시지 표시
        
        Args:
            error_message (str): 표시할 오류 메시지
        """
        print(f"\033[91m{error_message}\033[0m")  # 빨간색으로 표시
    
    def wait_for_input(self, message="\n계속하려면 Enter 키를 누르세요..."):
        """사용자 입력 대기
        
        Args:
            message (str): 표시할 메시지
        """
        input(message) 