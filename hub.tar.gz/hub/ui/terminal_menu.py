#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
터미널 메뉴 클래스
"""

import os
import sys

# 현재 스크립트 디렉토리 기준으로 경로 설정
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(os.path.dirname(current_dir))  # hub 디렉토리의 부모 디렉토리
sys.path.insert(0, parent_dir)

# 공통으로 사용하는 non-circular 모듈만 여기서 임포트
from hub.ui.views.menu_view import MenuView

class TerminalMenu:
    """터미널 기반 메뉴 클래스"""
    
    def __init__(self):
        """초기화"""
        # 메뉴 뷰 먼저 생성
        self.menu_view = MenuView()
        
        # 순환 참조 방지를 위한 레이지 임포트
        from hub.core.model.device_model import DeviceModel
        from hub.core.daemon.daemon_controller import DaemonController
        from hub.core.bluetooth.scanner import BluetoothScanner
        from hub.core.bluetooth.module_manager import BluetoothModuleManager
        from hub.core.bluetooth.device_manager import BluetoothDeviceManager
        from hub.core.bluetooth.relay_service import BluetoothRelayService
        from hub.ui.controllers.module_selector import ModuleSelector
        from hub.ui.controllers.device_controller import DeviceController
        from hub.ui.controllers.relay_controller import RelayController
        from hub.ui.controllers.daemon_controller import DaemonManagerController
        
        # 모델 및 서비스 인스턴스 생성
        self.device_model = DeviceModel()
        self.daemon_controller = DaemonController()
        self.menu_view = MenuView()
        self.bluetooth_scanner = BluetoothScanner()
        
        # 모듈화된 컴포넌트 초기화
        self.module_manager = BluetoothModuleManager(self.bluetooth_scanner, self.device_model)
        self.module_selector = ModuleSelector(self.module_manager, self.menu_view)
        
        # 블루투스 디바이스 관련 컴포넌트 초기화
        self.device_manager = BluetoothDeviceManager()
        self.device_controller = DeviceController(self.device_model, self.menu_view)
        
        # 릴레이 서비스 초기화
        self.relay_service = BluetoothRelayService(self.device_model)
        self.relay_controller = RelayController(self.relay_service, self.device_model, self.menu_view)
        
        # 프로그램 시작 시 설정 파일에서 블루투스 설정 로드
        self.load_config()
        
        # UI 컨트롤러 인스턴스 생성
        self.daemon_manager = DaemonManagerController(self.daemon_controller, self.menu_view)
    
    def load_config(self):
        """설정 파일에서 설정 로드"""
        # 데몬 컨트롤러의 설정 파일 경로
        config_file = self.daemon_controller.config_file
        
        # 항상 설정 파일 로드 시도 (데몬 상태와 관계없이)
        if os.path.exists(config_file):
            print(f"설정 파일 발견: {config_file}")
            print("블루투스 설정 로드 중...")
            
            # 설정 로드
            if self.daemon_controller._load_config():
                print("블루투스 설정 로드 성공!")
            else:
                print("블루투스 설정 로드 실패!")
        else:
            print(f"설정 파일이 없습니다: {config_file}")
            
        # 데몬 상태 업데이트
        self.daemon_controller.get_status()
    
    def run(self):
        """메뉴 실행"""
        while True:
            self.main_menu()
    
    def main_menu(self):
        """메인 메뉴 표시"""
        self.menu_view.clear_screen()
        self.menu_view.show_header("BLE-HUB 관리자")
        
        # 현재 상태 정보 표시
        daemon_status = self.daemon_controller.get_status()
        relay_status = "실행 중" if self.relay_service.is_running() else "중지됨"
        
        # 상태 정보 표시
        self.menu_view.show_status_info(
            daemon_status,
            self.device_model.get_source_module(),
            self.device_model.get_target_module(),
            self.device_model.get_receiving_devices(),
            self.device_model.get_transmitting_device()
        )
        
        # 메뉴 옵션 구성
        options = {
            "1": "데몬 관리",
            "2": "블루투스 디바이스 관리",
            "3": "수신-송신 연결 관리",
            "0": "종료"
        }
        
        self.menu_view.show_menu_options(options)
        choice = input("\n선택: ")
        
        if choice == "1":
            self.daemon_manager.daemon_menu()
        elif choice == "2":
            self.device_controller.device_menu()
        elif choice == "3":
            self.relay_controller.relay_menu()
        elif choice == "0":
            self.exit_program()
        else:
            self.menu_view.show_error("잘못된 선택입니다. 다시 시도해주세요.")
            self.menu_view.wait_for_input()
    
    def exit_program(self):
        """프로그램 종료"""
        self.menu_view.clear_screen()
        self.menu_view.show_header("프로그램 종료")
        
        # 릴레이 서비스가 실행 중이면 중지
        if self.relay_service.is_running():
            self.menu_view.show_message("릴레이 서비스를 중지합니다...")
            self.relay_service.stop_relay()
        
        # 데몬이 실행 중이면 계속 실행할지 물어봄
        if self.daemon_controller.is_running():
            choice = input("데몬이 실행 중입니다. 종료하시겠습니까? (y/n): ")
            if choice.lower() == 'y':
                self.menu_view.show_message("데몬을 종료합니다...")
                self.daemon_controller.stop()
        
        self.menu_view.show_message("프로그램을 종료합니다. 안녕히 가세요!")
        exit(0)

    def daemon_menu(self):
        """데몬 관리 메뉴"""
        while True:
            self.menu_view.clear_screen()
            self.menu_view.show_header("데몬 관리")
            
            # 데몬 상태 표시
            daemon_status = self.daemon_controller.get_status()
            print(f"\n현재 데몬 상태: {daemon_status}")
            
            # 메뉴 옵션 표시
            options = {
                "1": "데몬 시작",
                "2": "데몬 중지",
                "3": "데몬 재시작",
                "4": "데몬 상태 확인",
                "0": "이전 메뉴로 돌아가기"
            }
            self.menu_view.show_menu_options(options)
            
            choice = input("\n선택: ")
            
            if choice == "1":
                self.daemon_controller.start(self.device_model)
                self.menu_view.show_message("데몬이 시작되었습니다.")
                self.menu_view.wait_for_input()
            elif choice == "2":
                self.daemon_controller.stop(self.device_model)
                self.menu_view.show_message("데몬이 중지되었습니다.")
                self.menu_view.wait_for_input()
            elif choice == "3":
                self.daemon_controller.restart(self.device_model)
                self.menu_view.show_message("데몬이 재시작되었습니다.")
                self.menu_view.wait_for_input()
            elif choice == "4":
                daemon_status = self.daemon_controller.get_status()
                self.menu_view.show_message(f"\n데몬 상태: {daemon_status}")
                self.menu_view.wait_for_input()
            elif choice == "0":
                break
            else:
                self.menu_view.show_error("잘못된 선택입니다. 다시 시도하세요.")
                self.menu_view.wait_for_input()
    
    def bluetooth_menu(self):
        """블루투스 관리 메뉴"""
        while True:
            self.menu_view.clear_screen()
            self.menu_view.show_header("블루투스 관리")
            
            # 메뉴 옵션 표시
            options = {
                "1": "수신용 블루투스 모듈 선택",
                "2": "송신용 블루투스 모듈 선택",
                "3": "수신 블루투스 디바이스 추가",
                "4": "수신 블루투스 디바이스 삭제",
                "5": "수신 블루투스 디바이스 목록",
                "6": "송신 블루투스 디바이스 선택",
                "7": "송신 블루투스 디바이스 삭제",
                "0": "이전 메뉴로 돌아가기"
            }
            self.menu_view.show_menu_options(options)
            
            choice = input("\n선택: ")
            
            if choice == "1":
                self.module_selector.select_source_module()
            elif choice == "2":
                self.module_selector.select_target_module()
            elif choice == "3":
                self.device_controller.add_receiving_device()
            elif choice == "4":
                self.device_controller.remove_receiving_device()
            elif choice == "5":
                self.show_receiving_devices()
            elif choice == "6":
                self.device_controller.select_transmitting_device()
            elif choice == "7":
                self.device_controller.remove_transmitting_device()
            elif choice == "0":
                break
            else:
                self.menu_view.show_error("잘못된 선택입니다. 다시 시도하세요.")
                self.menu_view.wait_for_input()
                
    def show_receiving_devices(self):
        """수신 블루투스 디바이스 목록 표시"""
        self.menu_view.clear_screen()
        self.menu_view.show_header("수신 블루투스 디바이스 목록")
        
        receiving_devices = self.device_model.get_receiving_devices()
        
        if not receiving_devices:
            self.menu_view.show_message("\n등록된 수신 디바이스가 없습니다.")
        else:
            self.menu_view.show_message("\n== 등록된 수신 디바이스 ==")
            for i, device in enumerate(receiving_devices):
                self.menu_view.show_message(f"{i+1}. {device['name']} - {device['mac']}")
        
        self.menu_view.wait_for_input()
    
    def relay_menu(self):
        """수신-송신 연결 메뉴"""
        while True:
            # 릴레이 컨트롤러의 메뉴 표시
            result = self.relay_controller.relay_menu()
            
            # 이전 메뉴로 돌아가기
            if not result:
                break 