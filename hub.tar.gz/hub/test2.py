#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
라즈베리파이 키보드 & 마우스 HID 블루투스 설정
블루투스 이름을 'test2'로 설정하고 키보드와 마우스로만 광고합니다.

사용방법: sudo python3 test2.py
"""

import os
import sys
import subprocess
import time
import signal
import dbus
import dbus.service
import dbus.mainloop.glib
from gi.repository import GLib

# 블루투스 이름 및 설정
BLUETOOTH_NAME = "test2"
DEVICE_CLASS = 0x002520  # 키보드 + 마우스 전용 장치 클래스
HID_UUID = "00001124-0000-1000-8000-00805f9b34fb"  # HID 서비스 UUID

# 고유한 프로필 경로
PROFILE_PATH = "/test2/hidprofile"

# HID SDP 레코드 - 다중 프로필 (키보드 + 마우스)
HID_SDP_RECORD = {
    "ServiceRecord": """
        <?xml version="1.0" encoding="UTF-8" ?>
        <record>
            <attribute id="0x0001">
                <sequence>
                    <uuid value="0x1124"/>
                </sequence>
            </attribute>
            <attribute id="0x0004">
                <sequence>
                    <sequence>
                        <uuid value="0x0100"/>
                        <uint16 value="0x0011"/>
                    </sequence>
                    <sequence>
                        <uuid value="0x0011"/>
                    </sequence>
                </sequence>
            </attribute>
            <attribute id="0x0005">
                <sequence>
                    <uuid value="0x1124"/>
                </sequence>
            </attribute>
            <attribute id="0x0100">
                <text value="Test2 Keyboard/Mouse"/>
            </attribute>
            <attribute id="0x0101">
                <text value="Raspberry Pi Keyboard and Mouse HID Device"/>
            </attribute>
            <attribute id="0x0102">
                <text value="Raspberry Pi"/>
            </attribute>
            <attribute id="0x0200">
                <uint16 value="0x0100"/>
            </attribute>
            <attribute id="0x0201">
                <uint16 value="0x0111"/>
            </attribute>
            <attribute id="0x0202">
                <uint8 value="0xC0"/>
            </attribute>
            <attribute id="0x0203">
                <uint8 value="0x00"/>
            </attribute>
            <attribute id="0x0204">
                <boolean value="true"/>
            </attribute>
            <attribute id="0x0205">
                <boolean value="true"/>
            </attribute>
            <attribute id="0x0206">
                <sequence>
                    <uint8 value="0x22"/>
                    <uint8 value="0x40"/>
                    <uint8 value="0x0F"/>
                    <uint8 value="0x00"/>
                </sequence>
            </attribute>
            <attribute id="0x0207">
                <sequence>
                    <sequence>
                        <uint8 value="0x05"/>
                        <uint8 value="0x01"/>
                        <uint8 value="0x09"/>
                        <uint8 value="0x06"/>
                        <uint8 value="0xa1"/>
                        <uint8 value="0x01"/>
                        <uint8 value="0x05"/>
                        <uint8 value="0x07"/>
                        <uint8 value="0x19"/>
                        <uint8 value="0xe0"/>
                        <uint8 value="0x29"/>
                        <uint8 value="0xe7"/>
                        <uint8 value="0x15"/>
                        <uint8 value="0x00"/>
                        <uint8 value="0x25"/>
                        <uint8 value="0x01"/>
                        <uint8 value="0x75"/>
                        <uint8 value="0x01"/>
                        <uint8 value="0x95"/>
                        <uint8 value="0x08"/>
                        <uint8 value="0x81"/>
                        <uint8 value="0x02"/>
                        <uint8 value="0x95"/>
                        <uint8 value="0x01"/>
                        <uint8 value="0x75"/>
                        <uint8 value="0x08"/>
                        <uint8 value="0x81"/>
                        <uint8 value="0x01"/>
                        <uint8 value="0x95"/>
                        <uint8 value="0x06"/>
                        <uint8 value="0x75"/>
                        <uint8 value="0x08"/>
                        <uint8 value="0x15"/>
                        <uint8 value="0x00"/>
                        <uint8 value="0x25"/>
                        <uint8 value="0xff"/>
                        <uint8 value="0x05"/>
                        <uint8 value="0x07"/>
                        <uint8 value="0x19"/>
                        <uint8 value="0x00"/>
                        <uint8 value="0x29"/>
                        <uint8 value="0xff"/>
                        <uint8 value="0x81"/>
                        <uint8 value="0x00"/>
                        <uint8 value="0xc0"/>
                        <uint8 value="0x05"/>
                        <uint8 value="0x01"/>
                        <uint8 value="0x09"/>
                        <uint8 value="0x02"/>
                        <uint8 value="0xa1"/>
                        <uint8 value="0x01"/>
                        <uint8 value="0x09"/>
                        <uint8 value="0x01"/>
                        <uint8 value="0xa1"/>
                        <uint8 value="0x00"/>
                        <uint8 value="0x05"/>
                        <uint8 value="0x09"/>
                        <uint8 value="0x19"/>
                        <uint8 value="0x01"/>
                        <uint8 value="0x29"/>
                        <uint8 value="0x03"/>
                        <uint8 value="0x15"/>
                        <uint8 value="0x00"/>
                        <uint8 value="0x25"/>
                        <uint8 value="0x01"/>
                        <uint8 value="0x95"/>
                        <uint8 value="0x03"/>
                        <uint8 value="0x75"/>
                        <uint8 value="0x01"/>
                        <uint8 value="0x81"/>
                        <uint8 value="0x02"/>
                        <uint8 value="0x95"/>
                        <uint8 value="0x01"/>
                        <uint8 value="0x75"/>
                        <uint8 value="0x05"/>
                        <uint8 value="0x81"/>
                        <uint8 value="0x03"/>
                        <uint8 value="0x05"/>
                        <uint8 value="0x01"/>
                        <uint8 value="0x09"/>
                        <uint8 value="0x30"/>
                        <uint8 value="0x09"/>
                        <uint8 value="0x31"/>
                        <uint8 value="0x15"/>
                        <uint8 value="0x81"/>
                        <uint8 value="0x25"/>
                        <uint8 value="0x7f"/>
                        <uint8 value="0x75"/>
                        <uint8 value="0x08"/>
                        <uint8 value="0x95"/>
                        <uint8 value="0x02"/>
                        <uint8 value="0x81"/>
                        <uint8 value="0x06"/>
                        <uint8 value="0xc0"/>
                        <uint8 value="0xc0"/>
                    </sequence>
                </sequence>
            </attribute>
        </record>
    """
}

class MultiHIDProfile(dbus.service.Object):
    """블루투스 HID 프로필 서비스"""
    
    def __init__(self, bus, path):
        """초기화"""
        super(MultiHIDProfile, self).__init__(bus, path)
        
    @dbus.service.method("org.bluez.Profile1", in_signature="", out_signature="")
    def Release(self):
        """프로필 해제"""
        print("🔄 프로필 해제됨")
        
    @dbus.service.method("org.bluez.Profile1", in_signature="oha{sv}", out_signature="")
    def NewConnection(self, device, fd, properties):
        """새 연결 처리"""
        print(f"✅ 새 연결: {device}")
        self.fd = fd.take()
        print(f"🔌 파일 디스크립터: {self.fd}")
        print("🎮 장치가 연결되었습니다. 키보드와 마우스 입력이 활성화되었습니다.")
        
    @dbus.service.method("org.bluez.Profile1", in_signature="o", out_signature="")
    def RequestDisconnection(self, device):
        """연결 해제 요청 처리"""
        print(f"🔌 연결 해제: {device}")
        try:
            os.close(self.fd)
        except:
            pass

class BluetoothHID:
    """블루투스 키보드 & 마우스 HID 클래스"""
    
    def __init__(self):
        """초기화"""
        print("🔄 블루투스 키보드 & 마우스 HID 초기화 중...")
        
        # D-Bus 메인 루프 설정
        dbus.mainloop.glib.DBusGMainLoop(set_as_default=True)
        self.bus = dbus.SystemBus()
        
        # Bluez 설정
        self.adapter_obj = self.bus.get_object("org.bluez", "/org/bluez/hci0")
        self.adapter = dbus.Interface(self.adapter_obj, "org.bluez.Adapter1")
        self.adapter_props = dbus.Interface(self.adapter_obj, "org.freedesktop.DBus.Properties")
        
        # 프로필 설정
        self.profile_path = PROFILE_PATH
        self.profile = MultiHIDProfile(self.bus, self.profile_path)
        
        # 메인 루프
        self.mainloop = GLib.MainLoop()
        
    def setup(self):
        """블루투스 HID 설정"""
        try:
            # 블루투스 서비스 완전히 재시작
            print("🔄 블루투스 서비스 재시작 중...")
            subprocess.run(["sudo", "systemctl", "stop", "bluetooth"], check=True)
            time.sleep(1)
            
            # 블루투스 데몬 프로세스가 완전히 종료되었는지 확인
            try:
                subprocess.run(["sudo", "killall", "bluetoothd"], check=False)
            except:
                pass
                
            # 서비스 다시 시작
            time.sleep(1)
            subprocess.run(["sudo", "systemctl", "start", "bluetooth"], check=True)
            time.sleep(3)  # 서비스가 완전히 시작될 때까지 기다림
            
            # 블루투스 활성화
            print("🔄 블루투스 활성화 중...")
            subprocess.run(["bluetoothctl", "power", "on"], check=True)
            time.sleep(1)
            
            # 블루투스 이름 설정
            print(f"🔄 블루투스 이름을 '{BLUETOOTH_NAME}'로 변경 중...")
            subprocess.run(["bluetoothctl", "system-alias", BLUETOOTH_NAME], check=True)
            subprocess.run(["sudo", "hciconfig", "hci0", "name", BLUETOOTH_NAME], check=True)
            
            # 장치 클래스 설정 (키보드 + 마우스 전용)
            print("🔄 블루투스 장치 클래스를 키보드와 마우스로 설정 중...")
            subprocess.run(["sudo", "hciconfig", "hci0", "class", hex(DEVICE_CLASS).replace('0x', '')], check=True)
            
            # 검색 가능 및 페어링 가능 설정
            print("🔄 블루투스 검색 가능 설정 중...")
            subprocess.run(["bluetoothctl", "discoverable", "on"], check=True)
            subprocess.run(["bluetoothctl", "pairable", "on"], check=True)
            
            # 무제한 검색 가능 시간 설정
            subprocess.run(["bluetoothctl", "discoverable-timeout", "0"], check=True)
            
            # HID 프로필 등록
            self.register_hid_profile()
            
            # LE 광고 설정은 선택적으로 처리
            try:
                self.setup_le_advertisement()
            except:
                print("⚠️ LE 광고 설정을 건너뜁니다.")
            
            # 검증: 현재 설정 확인
            print("🔍 현재 블루투스 설정 확인 중...")
            subprocess.run(["hciconfig", "hci0"], check=True)
            
            print(f"✅ 블루투스 키보드 & 마우스 HID 장치 '{BLUETOOTH_NAME}'가 설정되었습니다.")
            print("✅ 이제 다른 장치에서 입력 장치로 검색할 수 있습니다.")
            return True
            
        except subprocess.CalledProcessError as e:
            print(f"❌ 명령 실행 오류: {e}")
            return False
        except Exception as e:
            print(f"❌ 예상치 못한 오류: {e}")
            return False
    
    def register_hid_profile(self):
        """HID 프로필 등록"""
        print("🔄 HID 프로필 등록 중...")
        
        try:
            # 프로필 매니저 가져오기
            profile_manager = dbus.Interface(
                self.bus.get_object("org.bluez", "/org/bluez"),
                "org.bluez.ProfileManager1"
            )
            
            # 기존 프로필 등록 해제 시도
            try:
                profile_manager.UnregisterProfile(self.profile_path)
                print("🔄 기존 프로필 등록 해제됨")
            except:
                pass
            
            # HID 프로필 등록
            profile_manager.RegisterProfile(
                self.profile_path,
                HID_UUID,
                HID_SDP_RECORD
            )
            
            print("✅ HID 프로필 등록 완료")
            return True
            
        except dbus.exceptions.DBusException as e:
            if "NotPermitted" in str(e) and "UUID already registered" in str(e):
                print("⚠️ 이미 동일한 UUID가 등록되어 있습니다. 장치 클래스만 설정합니다.")
                return True
            else:
                print(f"❌ HID 프로필 등록 오류: {e}")
                return False
        except Exception as e:
            print(f"❌ HID 프로필 등록 오류: {e}")
            return False
    
    def setup_le_advertisement(self):
        """블루투스 LE 광고 설정"""
        try:
            print("🔄 블루투스 LE 광고 설정 중...")
            
            # 일부 블루투스 어댑터는 LE 광고를 지원하지 않을 수 있음
            subprocess.run(["sudo", "hciconfig", "hci0", "leadv", "0"], check=False)
            time.sleep(0.5)
            
            # LE 광고 시작 시도
            try:
                subprocess.run(["sudo", "hciconfig", "hci0", "leadv", "3"], check=True)
                print("✅ 블루투스 LE 광고 설정 완료")
            except:
                print("⚠️ 이 블루투스 어댑터는 LE 광고를 지원하지 않거나 이미 다른 프로세스에서 사용 중입니다.")
                print("⚠️ LE 광고 없이 계속 진행합니다.")
            
            return True
        except Exception as e:
            print(f"⚠️ LE 광고 설정 오류 (무시해도 됨): {e}")
            return False
            
    def run(self):
        """서버 실행"""
        print(f"✅ 블루투스 키보드 & 마우스 HID 서버 시작됨. 디바이스 이름: {BLUETOOTH_NAME}")
        print("⏳ 다른 장치에서 블루투스 검색할 수 있습니다. Ctrl+C로 종료합니다.")
        
        # 메인 루프 시작
        self.mainloop.run()

def signal_handler(signum, frame):
    """시그널 핸들러"""
    print("\n🛑 프로그램 종료 중...")
    sys.exit(0)

def check_dependencies():
    """필요한 패키지 확인"""
    required_packages = ["bluez", "python3-dbus", "python3-gi"]
    missing_packages = []
    
    print("🔍 필요한 패키지 확인 중...")
    
    try:
        for package in required_packages:
            result = subprocess.run(["dpkg", "-s", package], 
                                   stdout=subprocess.PIPE, 
                                   stderr=subprocess.PIPE, 
                                   text=True)
            if result.returncode != 0:
                missing_packages.append(package)
    except:
        print("❌ 패키지 확인 중 오류가 발생했습니다.")
        
    if missing_packages:
        print("❌ 다음 패키지를 설치해야 합니다:")
        for package in missing_packages:
            print(f"   - {package}")
        print("\n다음 명령어로 설치하세요:")
        print(f"sudo apt update && sudo apt install {' '.join(missing_packages)}")
        return False
        
    print("✅ 필요한 패키지가 모두 설치되어 있습니다.")
    return True

if __name__ == "__main__":
    # 루트 권한 확인
    if os.geteuid() != 0:
        print("❌ 이 스크립트는 루트 권한으로 실행해야 합니다.")
        print("다음 명령으로 다시 실행하세요: sudo python3 test2.py")
        sys.exit(1)
    
    # 의존성 확인
    if not check_dependencies():
        print("⚠️ 필요한 패키지를 설치한 후 다시 실행하세요.")
        sys.exit(1)
    
    # 시그널 핸들러 설정
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    print("🚀 블루투스 키보드 & 마우스 HID 설정 스크립트 시작")
    print("=================================================")
    
    # 블루투스 키보드/마우스 HID 설정
    hid = BluetoothHID()
    if hid.setup():
        print("\n📱 스마트폰이나 컴퓨터에서 블루투스 장치 검색을 시도해보세요.")
        print(f"📡 '{BLUETOOTH_NAME}'이(가) 키보드 및 마우스 입력 장치로 표시될 것입니다.")
        print("⏳ 프로그램은 계속 실행 중입니다. Ctrl+C를 눌러 종료할 수 있습니다.")
        
        try:
            # 블루투스 HID 서버 실행
            hid.run()
        except KeyboardInterrupt:
            print("\n🛑 프로그램을 종료합니다.")
    else:
        print("❌ 블루투스 키보드 & 마우스 HID 설정에 실패했습니다.")
        sys.exit(1) 