#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
BLE-HUB 프로그램 메인 진입점
"""

import os
import sys

# 디렉토리 구조에 맞게 경로 설정
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def main():
    """프로그램 메인 함수"""
    # 순환 참조를 피하기 위해 여기서 임포트
    from hub.ui.terminal_menu import TerminalMenu
    
    # TerminalMenu 인스턴스 생성 및 실행
    terminal = TerminalMenu()
    terminal.run()

if __name__ == "__main__":
    main() 