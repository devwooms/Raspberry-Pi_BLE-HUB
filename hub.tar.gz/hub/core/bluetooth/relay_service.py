#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
블루투스 릴레이 서비스
"""

import time
import threading
import subprocess
from hub.core.bluetooth.device_manager import BluetoothDeviceManager

class BluetoothRelayService:
    """블루투스 릴레이 서비스 클래스"""
    
    def __init__(self, device_model):
        """초기화
        
        Args:
            device_model: 디바이스 모델 인스턴스
        """
        self.device_model = device_model
        self.device_manager = BluetoothDeviceManager()
        self.running = False
        self.relay_thread = None
        self.lock = threading.Lock()
    
    def start_relay(self):
        """릴레이 서비스 시작
        
        Returns:
            bool: 시작 성공 여부
        """
        with self.lock:
            if self.running:
                print("릴레이 서비스가 이미 실행 중입니다.")
                return False
            
            # 필요한 설정이 모두 있는지 확인
            if not self._check_prerequisites():
                return False
            
            # 릴레이 쓰레드 시작
            self.running = True
            self.relay_thread = threading.Thread(target=self._relay_worker)
            self.relay_thread.daemon = True
            self.relay_thread.start()
            
            print("릴레이 서비스가 시작되었습니다.")
            return True
    
    def stop_relay(self):
        """릴레이 서비스 중지
        
        Returns:
            bool: 중지 성공 여부
        """
        with self.lock:
            if not self.running:
                print("릴레이 서비스가 실행 중이 아닙니다.")
                return False
            
            # 릴레이 중지
            self.running = False
            
            # 쓰레드가 종료될 때까지 최대 5초 대기
            if self.relay_thread:
                self.relay_thread.join(timeout=5)
            
            # 블루투스 서비스 재시작하여 상태 복원
            try:
                subprocess.run('sudo systemctl restart bluetooth', shell=True, 
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                print("블루투스 서비스를 재시작했습니다.")
            except Exception as e:
                print(f"블루투스 서비스 재시작 중 오류: {e}")
            
            print("릴레이 서비스가 중지되었습니다.")
            return True
    
    def is_running(self):
        """릴레이 서비스 실행 상태 확인
        
        Returns:
            bool: 실행 중 여부
        """
        with self.lock:
            return self.running
    
    def _check_prerequisites(self):
        """릴레이에 필요한 설정이 모두 있는지 확인
        
        Returns:
            bool: 모든 필수 설정이 있는지 여부
        """
        source_module = self.device_model.get_source_module()
        if not source_module:
            print("수신용 블루투스 모듈이 설정되지 않았습니다.")
            return False
        
        target_module = self.device_model.get_target_module()
        if not target_module:
            print("송신용 블루투스 모듈이 설정되지 않았습니다.")
            return False
        
        receiving_devices = self.device_model.get_receiving_devices()
        if not receiving_devices:
            print("등록된 수신 디바이스가 없습니다.")
            return False
        
        transmitting_device = self.device_model.get_transmitting_device()
        if not transmitting_device:
            print("송신 디바이스가 설정되지 않았습니다.")
            return False
        
        return True
    
    def _relay_worker(self):
        """릴레이 작업을 수행하는 워커 쓰레드"""
        print("릴레이 작업을 시작합니다...")
        
        # 소스 모듈, 타겟 모듈, 디바이스 정보 가져오기
        source_module = self.device_model.get_source_module()
        target_module = self.device_model.get_target_module()
        receiving_devices = self.device_model.get_receiving_devices()
        transmitting_device = self.device_model.get_transmitting_device()
        
        print(f"수신 모듈: {source_module}")
        print(f"송신 모듈: {target_module}")
        print(f"수신 디바이스: {', '.join([d['name'] for d in receiving_devices])}")
        print(f"송신 디바이스: {transmitting_device['name']}")
        
        try:
            # 수신 디바이스 연결
            print("수신 디바이스에 연결 중...")
            for device in receiving_devices:
                print(f"- {device['name']} ({device['mac']})에 연결 시도...")
                if self.device_manager.connect_device(source_module, device['mac']):
                    print(f"  -> 연결 성공")
                else:
                    print(f"  -> 연결 실패")
            
            # 송신 디바이스 연결
            print(f"송신 디바이스 {transmitting_device['name']} ({transmitting_device['mac']})에 연결 중...")
            if self.device_manager.connect_device(target_module, transmitting_device['mac']):
                print("  -> 연결 성공")
            else:
                print("  -> 연결 실패")
            
            # 실제 릴레이 작업 수행
            while self.running:
                # 여기에 실제 릴레이 로직을 구현
                # 예: 수신 디바이스로부터 HID 이벤트를 읽어 송신 디바이스로 전달
                
                # 실제 구현에서는 아래 코드를 대체해야 함
                # 아래는 시뮬레이션을 위한 코드
                print("릴레이 실행 중...", end="\r")
                
                # 릴레이 명령 실행 예시
                # subprocess.run(['relay_command', source_module, target_module], 
                #               stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                
                time.sleep(1)
                
        except Exception as e:
            print(f"릴레이 작업 중 오류 발생: {e}")
        
        finally:
            # 연결 해제 및 정리
            print("\n릴레이 작업을 종료합니다...")
            try:
                for device in receiving_devices:
                    self.device_manager.disconnect_device(source_module, device['mac'])
                
                self.device_manager.disconnect_device(target_module, transmitting_device['mac'])
            except Exception as e:
                print(f"연결 해제 중 오류: {e}")
            
            self.running = False 