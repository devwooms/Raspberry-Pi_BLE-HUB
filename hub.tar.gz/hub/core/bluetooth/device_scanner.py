import subprocess
import re

class DeviceScanner:
    def get_discovered_devices(self, adapter='hci0'):
        """
        bluetoothctl 명령을 사용하여 이미 발견된 디바이스 목록을 가져옵니다.
        
        Args:
            adapter (str): 블루투스 어댑터 (hci0, hci1 등)
            
        Returns:
            list: 발견된 디바이스 목록
        """
        devices = []
        try:
            print(f"📋 {adapter} 어댑터의 발견된 장치 목록 가져오는 중...")
            
            # 명령 실행 시 어댑터 지정
            result = subprocess.run(
                ["bluetoothctl", "-i", adapter, "devices"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                timeout=5
            )
            
            if result.returncode != 0:
                print(f"❌ bluetoothctl devices 명령 실패: {result.stderr}")
                return devices
                
            output = result.stdout
            
            if not output.strip():
                print("ℹ️ 발견된 장치 없음")
                
                # 추가 정보 (장치가 없을 경우 문제 진단)
                print("🔍 장치 상태 확인 시도 중...")
                try:
                    # 어댑터 상태 확인
                    adapter_info = subprocess.run(
                        ["hciconfig", adapter],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        text=True,
                        timeout=3
                    )
                    print(f"ℹ️ {adapter} 상태:\n{adapter_info.stdout}")
                    
                    # bluetoothctl show 명령으로 어댑터 추가 정보 확인
                    show_info = subprocess.run(
                        ["bluetoothctl", "show", adapter],
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        text=True,
                        timeout=3
                    )
                    print(f"ℹ️ Bluetoothctl {adapter} 정보:\n{show_info.stdout}")
                except Exception as e:
                    print(f"⚠️ 어댑터 상태 확인 중 오류: {e}")
                
                return devices
            
            print(f"📝 bluetoothctl 출력:\n{output}")
            
            # 장치 정보 추출
            for line in output.splitlines():
                match = re.search(r'Device ([0-9A-F:]{17}) (.+)', line, re.IGNORECASE)
                if match:
                    mac = match.group(1)
                    name = match.group(2)
                    
                    # 추가 정보 가져오기
                    device_type = self._guess_device_type(name)
                    
                    # RSSI 값 가져오기 시도
                    rssi = None
                    try:
                        info_result = subprocess.run(
                            ["bluetoothctl", "info", mac],
                            stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE,
                            text=True,
                            timeout=3
                        )
                        info_output = info_result.stdout
                        
                        # RSSI 값 추출
                        rssi_match = re.search(r'RSSI: (-?\d+)', info_output)
                        if rssi_match:
                            rssi = int(rssi_match.group(1))
                    except Exception as e:
                        print(f"⚠️ {mac} 장치 정보 가져오기 실패: {e}")
                    
                    device = {
                        'mac': mac,
                        'name': name,
                        'type': device_type,
                        'rssi': rssi
                    }
                    
                    devices.append(device)
                    print(f"  → 장치 발견: {name} ({mac}), 유형: {device_type}, RSSI: {rssi}")
            
            if not devices:
                print("⚠️ 장치 정보는 있으나 파싱 실패")
                
        except Exception as e:
            print(f"❌ 장치 목록 가져오기 오류: {e}")
        
        return devices 

    def _guess_device_type(self, device_name):
        """
        장치 이름을 기반으로 장치 유형을 추측합니다.
        
        Args:
            device_name (str): 장치 이름
            
        Returns:
            str: 장치 유형 (마우스, 키보드, 스피커, 헤드폰, 스마트폰, 기타)
        """
        device_name = device_name.lower()
        
        # 마우스 관련 키워드
        if any(keyword in device_name for keyword in ['mouse', 'mx', 'mx master', 'mx vertical', 'trackpad']):
            return '마우스'
            
        # 키보드 관련 키워드
        elif any(keyword in device_name for keyword in ['keyboard', 'kbd', 'keychron', 'magic keyboard']):
            return '키보드'
            
        # 스피커 관련 키워드
        elif any(keyword in device_name for keyword in ['speaker', 'audio', 'sound']):
            return '스피커'
            
        # 헤드폰 관련 키워드
        elif any(keyword in device_name for keyword in ['headphone', 'headset', 'earphone', 'earbud', 'airpod']):
            return '헤드폰'
            
        # 스마트폰 관련 키워드
        elif any(keyword in device_name for keyword in ['phone', 'iphone', 'galaxy', 'pixel']):
            return '스마트폰'
            
        # 기본값
        return '기타' 