#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
블루투스 디바이스 관리자
"""

import subprocess
import time
import re
import os

class BluetoothDeviceManager:
    """블루투스 디바이스 관리 클래스"""
    
    def __init__(self):
        """초기화"""
        pass
    
    def get_bluetooth_interfaces(self):
        """시스템에 등록된 블루투스 인터페이스 목록 반환
        
        Returns:
            list: 블루투스 인터페이스 목록 (MAC 주소)
        """
        interfaces = []
        try:
            # hciconfig 실행
            result = subprocess.run(['hciconfig'], capture_output=True, text=True)
            if result.returncode == 0:
                # 정규식으로 MAC 주소 추출
                pattern = r'hci\d+.*?BD Address: ([0-9A-F:]{17})'
                matches = re.findall(pattern, result.stdout, re.DOTALL)
                interfaces = matches
        except Exception as e:
            print(f"블루투스 인터페이스 조회 중 오류: {e}")
        
        return interfaces
    
    def scan_devices(self, adapter='hci0', timeout=10):
        """블루투스 디바이스 스캔
        
        Args:
            adapter (str): 블루투스 어댑터 이름
            timeout (int): 스캔 시간 (초)
            
        Returns:
            list: 발견된 디바이스 목록
        """
        devices = []
        try:
            # 스캔 진행
            scan_cmd = f"timeout {timeout} bluetoothctl --timeout {timeout} scan on"
            subprocess.run(scan_cmd, shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            # 디바이스 목록 가져오기
            devices_cmd = "bluetoothctl devices"
            result = subprocess.run(devices_cmd, shell=True, capture_output=True, text=True)
            
            # 정규식으로 디바이스 정보 추출
            pattern = r'Device ([0-9A-F:]{17}) (.+)'
            matches = re.findall(pattern, result.stdout)
            
            for match in matches:
                mac = match[0]
                name = match[1]
                
                # RSSI 정보 얻기
                rssi_cmd = f"bluetoothctl info {mac}"
                rssi_result = subprocess.run(rssi_cmd, shell=True, capture_output=True, text=True)
                rssi_match = re.search(r'RSSI: (-\d+)', rssi_result.stdout)
                rssi = rssi_match.group(1) if rssi_match else None
                
                devices.append({
                    'mac': mac,
                    'name': name,
                    'rssi': rssi
                })
                
        except Exception as e:
            print(f"블루투스 스캔 중 오류: {e}")
        
        return devices
    
    def scan_with_progress(self, adapter='hci0', timeout=10):
        """진행 상황을 표시하며 블루투스 디바이스 스캔
        
        Args:
            adapter (str): 블루투스 어댑터 이름
            timeout (int): 스캔 시간 (초)
            
        Returns:
            list: 발견된 디바이스 목록
        """
        devices = []
        try:
            # 스캔 시작
            scan_process = subprocess.Popen(
                f"bluetoothctl scan on",
                shell=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                bufsize=1
            )
            
            # 진행 상황 표시
            start_time = time.time()
            discovered_count = 0
            
            while time.time() - start_time < timeout:
                elapsed = int(time.time() - start_time)
                remaining = timeout - elapsed
                
                # 현재까지의 디바이스 목록 가져와서 표시
                temp_devices = self._get_discovered_devices(adapter)
                if len(temp_devices) > discovered_count:
                    discovered_count = len(temp_devices)
                    print(f"\r진행중: {elapsed}초 경과 / {remaining}초 남음 - 발견된 디바이스: {discovered_count}개", end="")
                else:
                    print(f"\r진행중: {elapsed}초 경과 / {remaining}초 남음 - 발견된 디바이스: {discovered_count}개", end="")
                
                time.sleep(1)
            
            print("\n스캔 완료!")
            
            # 스캔 종료
            try:
                scan_process.terminate()
                scan_process.wait(timeout=2)
            except:
                scan_process.kill()
            
            # 블루투스 스캔 중지
            subprocess.run("bluetoothctl scan off", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            
            # 최종 디바이스 목록 가져오기
            devices = self._get_discovered_devices(adapter)
            
        except Exception as e:
            print(f"블루투스 스캔 중 오류: {e}")
            # 스캔 상태 정리
            subprocess.run("bluetoothctl scan off", shell=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        
        return devices
    
    def _get_discovered_devices(self, adapter='hci0'):
        """발견된 블루투스 디바이스 목록 반환
        
        Args:
            adapter (str): 블루투스 어댑터 이름
            
        Returns:
            list: 발견된 디바이스 목록
        """
        devices = []
        try:
            # 디바이스 목록 가져오기
            result = subprocess.run("bluetoothctl devices", shell=True, capture_output=True, text=True)
            
            # 정규식으로 디바이스 정보 추출
            pattern = r'Device ([0-9A-F:]{17}) (.+)'
            matches = re.findall(pattern, result.stdout)
            
            for match in matches:
                mac = match[0]
                name = match[1]
                
                # RSSI 정보 얻기 시도
                try:
                    rssi_cmd = f"bluetoothctl info {mac}"
                    rssi_result = subprocess.run(rssi_cmd, shell=True, capture_output=True, text=True, timeout=1)
                    rssi_match = re.search(r'RSSI: (-\d+)', rssi_result.stdout)
                    rssi = rssi_match.group(1) if rssi_match else "N/A"
                except:
                    rssi = "N/A"
                
                devices.append({
                    'mac': mac,
                    'name': name,
                    'rssi': rssi
                })
                
        except Exception as e:
            print(f"디바이스 목록 조회 중 오류: {e}")
        
        return devices
    
    def pair_device(self, adapter, mac_address):
        """블루투스 디바이스 페어링
        
        Args:
            adapter (str): 블루투스 어댑터 이름
            mac_address (str): 디바이스 MAC 주소
            
        Returns:
            bool: 페어링 성공 여부
        """
        try:
            # 이미 페어링된 디바이스인지 확인
            info_cmd = f"bluetoothctl info {mac_address}"
            info_result = subprocess.run(info_cmd, shell=True, capture_output=True, text=True)
            
            if "Paired: yes" in info_result.stdout:
                print(f"디바이스 {mac_address}는 이미 페어링되어 있습니다.")
                return True
            
            # 페어링 수행
            pair_cmd = f"bluetoothctl pair {mac_address}"
            pair_result = subprocess.run(pair_cmd, shell=True, capture_output=True, text=True, timeout=30)
            
            if "Pairing successful" in pair_result.stdout:
                print(f"디바이스 {mac_address} 페어링 성공")
                return True
            else:
                print(f"디바이스 {mac_address} 페어링 실패")
                return False
                
        except Exception as e:
            print(f"디바이스 페어링 중 오류: {e}")
            return False
    
    def trust_device(self, adapter, mac_address):
        """블루투스 디바이스 신뢰 설정
        
        Args:
            adapter (str): 블루투스 어댑터 이름
            mac_address (str): 디바이스 MAC 주소
            
        Returns:
            bool: 신뢰 설정 성공 여부
        """
        try:
            # 신뢰 설정
            trust_cmd = f"bluetoothctl trust {mac_address}"
            trust_result = subprocess.run(trust_cmd, shell=True, capture_output=True, text=True)
            
            if "trust succeeded" in trust_result.stdout.lower():
                print(f"디바이스 {mac_address} 신뢰 설정 성공")
                return True
            else:
                print(f"디바이스 {mac_address} 신뢰 설정 실패")
                return False
                
        except Exception as e:
            print(f"디바이스 신뢰 설정 중 오류: {e}")
            return False
    
    def connect_device(self, adapter, mac_address):
        """블루투스 디바이스 연결
        
        Args:
            adapter (str): 블루투스 어댑터 이름
            mac_address (str): 디바이스 MAC 주소
            
        Returns:
            bool: 연결 성공 여부
        """
        try:
            # 연결 시도
            connect_cmd = f"bluetoothctl connect {mac_address}"
            connect_result = subprocess.run(connect_cmd, shell=True, capture_output=True, text=True, timeout=20)
            
            if "Connection successful" in connect_result.stdout:
                print(f"디바이스 {mac_address} 연결 성공")
                return True
            else:
                print(f"디바이스 {mac_address} 연결 실패")
                return False
                
        except Exception as e:
            print(f"디바이스 연결 중 오류: {e}")
            return False
    
    def disconnect_device(self, adapter, mac_address):
        """블루투스 디바이스 연결 해제
        
        Args:
            adapter (str): 블루투스 어댑터 이름
            mac_address (str): 디바이스 MAC 주소
            
        Returns:
            bool: 연결 해제 성공 여부
        """
        try:
            # 연결 해제
            disconnect_cmd = f"bluetoothctl disconnect {mac_address}"
            disconnect_result = subprocess.run(disconnect_cmd, shell=True, capture_output=True, text=True)
            
            if "Successful disconnected" in disconnect_result.stdout:
                print(f"디바이스 {mac_address} 연결 해제 성공")
                return True
            else:
                print(f"디바이스 {mac_address} 연결 해제됨")
                return True
                
        except Exception as e:
            print(f"디바이스 연결 해제 중 오류: {e}")
            return False
    
    def remove_device(self, adapter, mac_address):
        """블루투스 디바이스 삭제
        
        Args:
            adapter (str): 블루투스 어댑터 이름
            mac_address (str): 디바이스 MAC 주소
            
        Returns:
            bool: 삭제 성공 여부
        """
        try:
            # 디바이스 삭제
            remove_cmd = f"bluetoothctl remove {mac_address}"
            remove_result = subprocess.run(remove_cmd, shell=True, capture_output=True, text=True)
            
            if "Device has been removed" in remove_result.stdout:
                print(f"디바이스 {mac_address} 삭제 성공")
                return True
            else:
                print(f"디바이스 {mac_address} 삭제 실패")
                return False
                
        except Exception as e:
            print(f"디바이스 삭제 중 오류: {e}")
            return False 