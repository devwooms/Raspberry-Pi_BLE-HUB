#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
블루투스 디바이스 모델
"""

import os
import json

class DeviceModel:
    """블루투스 디바이스 정보 관리 클래스"""
    
    def __init__(self, config_file="blehub_config.json"):
        """초기화
        
        Args:
            config_file (str): 설정 파일 경로
        """
        self.config_file = config_file
        self.source_module = None
        self.target_module = None
        self.receiving_devices = []
        self.transmitting_device = None
        
        # 설정 파일 불러오기
        self._load_config()
    
    def _load_config(self):
        """설정 파일에서 정보 불러오기"""
        try:
            if os.path.exists(self.config_file):
                with open(self.config_file, 'r') as f:
                    config = json.load(f)
                    
                    self.source_module = config.get('source_module')
                    self.target_module = config.get('target_module')
                    self.receiving_devices = config.get('receiving_devices', [])
                    self.transmitting_device = config.get('transmitting_device')
        except Exception as e:
            print(f"설정 파일 로드 중 오류: {e}")
    
    def _save_config(self):
        """설정 파일에 정보 저장"""
        try:
            config = {
                'source_module': self.source_module,
                'target_module': self.target_module,
                'receiving_devices': self.receiving_devices,
                'transmitting_device': self.transmitting_device
            }
            
            with open(self.config_file, 'w') as f:
                json.dump(config, f, indent=2)
        except Exception as e:
            print(f"설정 파일 저장 중 오류: {e}")
    
    def get_source_module(self):
        """수신용 블루투스 모듈 MAC 주소 반환
        
        Returns:
            str: 블루투스 모듈 MAC 주소 또는 None
        """
        return self.source_module
    
    def set_source_module(self, mac_address):
        """수신용 블루투스 모듈 설정
        
        Args:
            mac_address (str): 블루투스 모듈 MAC 주소
        """
        self.source_module = mac_address
        self._save_config()
    
    def get_target_module(self):
        """송신용 블루투스 모듈 MAC 주소 반환
        
        Returns:
            str: 블루투스 모듈 MAC 주소 또는 None
        """
        return self.target_module
    
    def set_target_module(self, mac_address):
        """송신용 블루투스 모듈 설정
        
        Args:
            mac_address (str): 블루투스 모듈 MAC 주소
        """
        self.target_module = mac_address
        self._save_config()
    
    def get_receiving_devices(self):
        """등록된 수신 디바이스 목록 반환
        
        Returns:
            list: 수신 디바이스 목록
        """
        return self.receiving_devices
    
    def add_receiving_device(self, device):
        """수신 디바이스 추가
        
        Args:
            device (dict): 디바이스 정보 (name, mac 포함)
        """
        # 중복 체크
        for existing in self.receiving_devices:
            if existing['mac'] == device['mac']:
                return False
        
        self.receiving_devices.append(device)
        self._save_config()
        return True
    
    def remove_receiving_device(self, device):
        """수신 디바이스 삭제
        
        Args:
            device (dict): 삭제할 디바이스 정보
            
        Returns:
            bool: 삭제 성공 여부
        """
        for i, existing in enumerate(self.receiving_devices):
            if existing['mac'] == device['mac']:
                del self.receiving_devices[i]
                self._save_config()
                return True
        return False
    
    def get_transmitting_device(self):
        """송신 디바이스 정보 반환
        
        Returns:
            dict: 송신 디바이스 정보 또는 None
        """
        return self.transmitting_device
    
    def set_transmitting_device(self, device):
        """송신 디바이스 설정
        
        Args:
            device (dict): 디바이스 정보 (name, mac 포함)
        """
        self.transmitting_device = device
        self._save_config()
    
    def clear_transmitting_device(self):
        """송신 디바이스 정보 삭제"""
        self.transmitting_device = None
        self._save_config()
    
    def clear_all_devices(self):
        """모든 디바이스 정보 초기화"""
        self.receiving_devices = []
        self.transmitting_device = None
        self._save_config()
    
    def is_ready_for_relay(self):
        """릴레이 준비 상태 확인
        
        Returns:
            bool: 릴레이 준비 완료 여부
        """
        return (self.source_module is not None and 
                self.target_module is not None and 
                len(self.receiving_devices) > 0 and 
                self.transmitting_device is not None) 