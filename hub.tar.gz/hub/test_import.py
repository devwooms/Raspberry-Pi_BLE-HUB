#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Import 테스트 스크립트
이 스크립트로 각 모듈이 올바르게 로드되는지 확인합니다.
"""

import os
import sys

# 경로 설정을 위한 코드
current_dir = os.path.dirname(os.path.abspath(__file__))
parent_dir = os.path.dirname(current_dir)
sys.path.insert(0, parent_dir)

print("Import 테스트 시작...")

try:
    print("- DeviceModel 임포트 테스트...")
    from hub.core.model.device_model import DeviceModel
    print("  -> 성공!")
    
    print("- BluetoothDeviceManager 임포트 테스트...")
    from hub.core.bluetooth.device_manager import BluetoothDeviceManager
    print("  -> 성공!")
    
    print("- BluetoothRelayService 임포트 테스트...")
    from hub.core.bluetooth.relay_service import BluetoothRelayService
    print("  -> 성공!")
    
    print("- MenuView 임포트 테스트...")
    from hub.ui.views.menu_view import MenuView
    print("  -> 성공!")
    
    print("- DeviceController 임포트 테스트...")
    from hub.ui.controllers.device_controller import DeviceController
    print("  -> 성공!")
    
    print("- DaemonManagerController 임포트 테스트...")
    from hub.ui.controllers.daemon_controller import DaemonManagerController
    print("  -> 성공!")
    
    print("- RelayController 임포트 테스트...")
    from hub.ui.controllers.relay_controller import RelayController
    print("  -> 성공!")
    
    print("- TerminalMenu 임포트 테스트...")
    from hub.ui.terminal_menu import TerminalMenu
    print("  -> 성공!")
    
    print("\n모든 임포트 테스트 성공!")

except ImportError as e:
    print(f"\n임포트 오류 발생: {e}")
    print(f"모듈 경로: {e.__traceback__.tb_frame.f_globals['__name__']}")
    
    # 현재 파이썬 경로 출력
    print("\n현재 Python 경로:")
    for path in sys.path:
        print(f"- {path}")
        
    # 모듈 디렉토리 체크
    for module_path in ["hub/core/model", "hub/core/bluetooth", "hub/ui/controllers", "hub/ui/views"]:
        abs_path = os.path.join(parent_dir, module_path)
        if os.path.exists(abs_path):
            print(f"\n{module_path} 디렉토리 내용:")
            for item in os.listdir(abs_path):
                print(f"- {item}")
        else:
            print(f"\n{module_path} 디렉토리가 존재하지 않습니다!") 