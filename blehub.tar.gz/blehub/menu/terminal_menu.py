#!/usr/bin/env python3
import os
import sys
import argparse

from blehub.utils.logger import logger, set_log_level
from blehub.configs.config_manager import ConfigManager
from blehub.daemon.manager import DaemonManager
from blehub.bluetooth.scanner import (
    list_bluetooth_modules,
    select_bluetooth_module,
    select_bluetooth_interface,
    select_bluetooth_device
)

"""
BLE-HUB 터미널 메뉴 모듈

명령줄 인터페이스를 제공합니다.
"""

class TerminalMenu:
    """터미널 메뉴 클래스"""
    
    def __init__(self):
        """터미널 메뉴 초기화"""
        self.config_manager = ConfigManager()
        self.daemon_manager = DaemonManager(self.config_manager)
    
    def main_menu(self):
        """메인 메뉴 표시"""
        while True:
            self._clear_screen()
            print("\n" + "=" * 60)
            print("BLE-HUB 블루투스 릴레이 관리 시스템".center(60))
            print("=" * 60)
            
            daemon_status = self.daemon_manager.status()
            
            # 데몬 상태 표시
            if daemon_status["running"]:
                print("✅ 데몬 상태: 실행 중")
                print(f"   소스 어댑터: {daemon_status.get('source_adapter', 'Unknown')}")
                print(f"   타겟 어댑터: {daemon_status.get('target_adapter', 'Unknown')}")
                print(f"   타겟 장치: {daemon_status.get('target_device', 'Unknown')}")
            else:
                print("⚠️  데몬 상태: 중지됨")
            
            print("\n메뉴:")
            print("1. 데몬 관리")
            print("2. 블루투스 모듈 관리")
            print("3. 설정 관리")
            print("4. 로그 레벨 설정")
            print("0. 종료")
            
            choice = input("\n선택: ")
            
            if choice == "1":
                self.daemon_menu()
            elif choice == "2":
                self.bluetooth_menu()
            elif choice == "3":
                self.config_menu()
            elif choice == "4":
                self.log_level_menu()
            elif choice == "0":
                print("프로그램을 종료합니다.")
                break
            else:
                print("잘못된 선택입니다. 다시 시도하세요.")
                input("계속하려면 Enter 키를 누르세요...")
    
    def daemon_menu(self):
        """데몬 관리 메뉴"""
        while True:
            self._clear_screen()
            print("\n" + "=" * 60)
            print("데몬 관리".center(60))
            print("=" * 60)
            
            daemon_status = self.daemon_manager.status()
            
            # 데몬 상태 표시
            if daemon_status["running"]:
                print("✅ 데몬 상태: 실행 중")
                print(f"   소스 어댑터: {daemon_status.get('source_adapter', 'Unknown')}")
                print(f"   타겟 어댑터: {daemon_status.get('target_adapter', 'Unknown')}")
                print(f"   타겟 장치: {daemon_status.get('target_device', 'Unknown')}")
            else:
                print("⚠️  데몬 상태: 중지됨")
            
            print("\n메뉴:")
            print("1. 데몬 시작")
            print("2. 데몬 중지")
            print("3. 데몬 재시작")
            print("4. 데몬 상태 확인")
            print("0. 이전 메뉴로 돌아가기")
            
            choice = input("\n선택: ")
            
            if choice == "1":
                if not self.daemon_manager.start():
                    input("계속하려면 Enter 키를 누르세요...")
                else:
                    print("데몬이 시작되었습니다.")
                    input("계속하려면 Enter 키를 누르세요...")
            elif choice == "2":
                if not self.daemon_manager.stop():
                    input("계속하려면 Enter 키를 누르세요...")
                else:
                    print("데몬이 중지되었습니다.")
                    input("계속하려면 Enter 키를 누르세요...")
            elif choice == "3":
                if not self.daemon_manager.restart():
                    input("계속하려면 Enter 키를 누르세요...")
                else:
                    print("데몬이 재시작되었습니다.")
                    input("계속하려면 Enter 키를 누르세요...")
            elif choice == "4":
                status = self.daemon_manager.status()
                print("\n데몬 상태:")
                for key, value in status.items():
                    print(f"{key}: {value}")
                input("\n계속하려면 Enter 키를 누르세요...")
            elif choice == "0":
                break
            else:
                print("잘못된 선택입니다. 다시 시도하세요.")
                input("계속하려면 Enter 키를 누르세요...")
    
    def bluetooth_menu(self):
        """블루투스 관리 메뉴"""
        while True:
            self._clear_screen()
            print("\n" + "=" * 60)
            print("블루투스 관리".center(60))
            print("=" * 60)
            
            print("\n메뉴:")
            print("1. 블루투스 모듈 목록 표시")
            print("2. 블루투스 모듈 선택")
            print("3. 소스 블루투스 인터페이스 선택")
            print("4. 타겟 블루투스 인터페이스 선택")
            print("5. 타겟 블루투스 장치 선택")
            print("0. 이전 메뉴로 돌아가기")
            
            choice = input("\n선택: ")
            
            if choice == "1":
                list_bluetooth_modules()
                input("\n계속하려면 Enter 키를 누르세요...")
            elif choice == "2":
                module = select_bluetooth_module()
                if module:
                    print(f"\n선택된 모듈: {module['description']}")
                    # 필요한 경우 추가 작업 수행
                input("\n계속하려면 Enter 키를 누르세요...")
            elif choice == "3":
                interface = select_bluetooth_interface()
                if interface:
                    print(f"\n선택된 인터페이스: {interface['id']}")
                    self.config_manager.set_config("source_adapter", interface['id'])
                    self.config_manager.save_config()
                    print(f"소스 어댑터가 {interface['id']}로 설정되었습니다.")
                input("\n계속하려면 Enter 키를 누르세요...")
            elif choice == "4":
                interface = select_bluetooth_interface()
                if interface:
                    print(f"\n선택된 인터페이스: {interface['id']}")
                    self.config_manager.set_config("target_adapter", interface['id'])
                    self.config_manager.save_config()
                    print(f"타겟 어댑터가 {interface['id']}로 설정되었습니다.")
                input("\n계속하려면 Enter 키를 누르세요...")
            elif choice == "5":
                # 타겟 장치를 스캔하기 위해 타겟 어댑터 확인
                target_adapter = self.config_manager.get_config("target_adapter", "hci0")
                device = select_bluetooth_device(target_adapter)
                if device:
                    print(f"\n선택된 장치: {device['name']} ({device['mac']})")
                    self.config_manager.set_config("target_device", device['mac'])
                    self.config_manager.save_config()
                    print(f"타겟 장치가 {device['mac']}로 설정되었습니다.")
                input("\n계속하려면 Enter 키를 누르세요...")
            elif choice == "0":
                break
            else:
                print("잘못된 선택입니다. 다시 시도하세요.")
                input("계속하려면 Enter 키를 누르세요...")
    
    def config_menu(self):
        """설정 관리 메뉴"""
        while True:
            self._clear_screen()
            print("\n" + "=" * 60)
            print("설정 관리".center(60))
            print("=" * 60)
            
            # 현재 설정 표시
            config = self.config_manager.get_full_config()
            print("\n현재 설정:")
            for section, values in config.items():
                print(f"{section}:")
                if isinstance(values, dict):
                    for key, value in values.items():
                        print(f"  {key}: {value}")
                else:
                    print(f"  {values}")
            
            print("\n메뉴:")
            print("1. 설정 저장")
            print("2. 설정 불러오기")
            print("3. 설정 초기화")
            print("0. 이전 메뉴로 돌아가기")
            
            choice = input("\n선택: ")
            
            if choice == "1":
                self.config_manager.save_config()
                print("설정이 저장되었습니다.")
                input("계속하려면 Enter 키를 누르세요...")
            elif choice == "2":
                self.config_manager.load_config()
                print("설정이 불러와졌습니다.")
                input("계속하려면 Enter 키를 누르세요...")
            elif choice == "3":
                confirm = input("정말로 설정을 초기화하시겠습니까? (y/n): ")
                if confirm.lower() == 'y':
                    self.config_manager.reset_config()
                    print("설정이 초기화되었습니다.")
                input("계속하려면 Enter 키를 누르세요...")
            elif choice == "0":
                break
            else:
                print("잘못된 선택입니다. 다시 시도하세요.")
                input("계속하려면 Enter 키를 누르세요...")
    
    def log_level_menu(self):
        """로그 레벨 설정 메뉴"""
        while True:
            self._clear_screen()
            print("\n" + "=" * 60)
            print("로그 레벨 설정".center(60))
            print("=" * 60)
            
            print("\n메뉴:")
            print("1. DEBUG 레벨 설정")
            print("2. INFO 레벨 설정")
            print("3. WARNING 레벨 설정")
            print("4. ERROR 레벨 설정")
            print("0. 이전 메뉴로 돌아가기")
            
            choice = input("\n선택: ")
            
            if choice == "1":
                set_log_level("DEBUG")
                print("로그 레벨이 DEBUG로 설정되었습니다.")
                input("계속하려면 Enter 키를 누르세요...")
            elif choice == "2":
                set_log_level("INFO")
                print("로그 레벨이 INFO로 설정되었습니다.")
                input("계속하려면 Enter 키를 누르세요...")
            elif choice == "3":
                set_log_level("WARNING")
                print("로그 레벨이 WARNING으로 설정되었습니다.")
                input("계속하려면 Enter 키를 누르세요...")
            elif choice == "4":
                set_log_level("ERROR")
                print("로그 레벨이 ERROR로 설정되었습니다.")
                input("계속하려면 Enter 키를 누르세요...")
            elif choice == "0":
                break
            else:
                print("잘못된 선택입니다. 다시 시도하세요.")
                input("계속하려면 Enter 키를 누르세요...")
    
    def _clear_screen(self):
        """화면 지우기"""
        os.system('cls' if os.name == 'nt' else 'clear')

def run_terminal_menu():
    """터미널 메뉴 실행"""
    menu = TerminalMenu()
    menu.main_menu()

def parse_arguments():
    """명령줄 인수 파싱
    
    Returns:
        argparse.Namespace: 파싱된 인수
    """
    parser = argparse.ArgumentParser(description="BLE-HUB 블루투스 릴레이 데몬 관리")
    
    # 데몬 관리 인수
    parser.add_argument('--start', action='store_true', help='데몬 시작')
    parser.add_argument('--stop', action='store_true', help='데몬 중지')
    parser.add_argument('--restart', action='store_true', help='데몬 재시작')
    parser.add_argument('--status', action='store_true', help='데몬 상태 확인')
    
    # 블루투스 관리 인수
    parser.add_argument('--list-modules', action='store_true', help='블루투스 모듈 목록 표시')
    parser.add_argument('--select-module', action='store_true', help='블루투스 모듈 선택')
    
    # 설정 인수
    parser.add_argument('--config', action='store_true', help='설정 표시')
    parser.add_argument('--set-source', type=str, help='소스 어댑터 설정')
    parser.add_argument('--set-target-adapter', type=str, help='타겟 어댑터 설정')
    parser.add_argument('--set-target-device', type=str, help='타겟 장치 설정')
    
    # 로그 인수
    parser.add_argument('--log-level', type=str, choices=['DEBUG', 'INFO', 'WARNING', 'ERROR'],
                        help='로그 레벨 설정')
    
    # 메뉴 인수
    parser.add_argument('--menu', action='store_true', help='터미널 메뉴 실행')
    
    return parser.parse_args()

def process_arguments(args):
    """명령줄 인수 처리
    
    Args:
        args (argparse.Namespace): 파싱된 인수
        
    Returns:
        bool: 처리 성공 여부
    """
    config_manager = ConfigManager()
    daemon_manager = DaemonManager(config_manager)
    
    # 로그 레벨 설정
    if args.log_level:
        set_log_level(args.log_level)
        print(f"로그 레벨이 {args.log_level}로 설정되었습니다.")
    
    # 블루투스 관리
    if args.list_modules:
        list_bluetooth_modules()
        return True
    
    if args.select_module:
        select_bluetooth_module()
        return True
    
    # 설정 관리
    if args.set_source:
        config_manager.set_config("source_adapter", args.set_source)
        config_manager.save_config()
        print(f"소스 어댑터가 {args.set_source}로 설정되었습니다.")
    
    if args.set_target_adapter:
        config_manager.set_config("target_adapter", args.set_target_adapter)
        config_manager.save_config()
        print(f"타겟 어댑터가 {args.set_target_adapter}로 설정되었습니다.")
    
    if args.set_target_device:
        config_manager.set_config("target_device", args.set_target_device)
        config_manager.save_config()
        print(f"타겟 장치가 {args.set_target_device}로 설정되었습니다.")
    
    if args.config:
        config = config_manager.get_full_config()
        print("\n현재 설정:")
        for section, values in config.items():
            print(f"{section}:")
            if isinstance(values, dict):
                for key, value in values.items():
                    print(f"  {key}: {value}")
            else:
                print(f"  {values}")
        return True
    
    # 데몬 관리
    if args.start:
        return daemon_manager.start()
    
    if args.stop:
        return daemon_manager.stop()
    
    if args.restart:
        return daemon_manager.restart()
    
    if args.status:
        status = daemon_manager.status()
        print("\n데몬 상태:")
        for key, value in status.items():
            print(f"{key}: {value}")
        return True
    
    # 메뉴 실행
    if args.menu:
        run_terminal_menu()
        return True
    
    # 아무 인수도 지정되지 않은 경우 메뉴 실행
    if len(sys.argv) <= 1:
        run_terminal_menu()
        return True
    
    return False

def main():
    """메인 함수"""
    args = parse_arguments()
    success = process_arguments(args)
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main() 